DELETE FROM client_apartments;
DELETE FROM clients;