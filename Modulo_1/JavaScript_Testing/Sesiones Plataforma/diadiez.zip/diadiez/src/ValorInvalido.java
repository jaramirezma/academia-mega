public class ValorInvalido extends Exception{

    public ValorInvalido(){}
    public ValorInvalido(String mensaje){
        super(mensaje);
    }
}
