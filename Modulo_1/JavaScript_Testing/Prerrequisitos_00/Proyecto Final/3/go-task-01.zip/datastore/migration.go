package datastore
 
import (
	"log"
 
	"github.com/golang-migrate/migrate/v4"
	_ "github.com/golang-migrate/migrate/v4/database/sqlite3"
	_ "github.com/golang-migrate/migrate/v4/source/file"
)
 
func InitializeDatabase(migrationFolder, driver string) {
	log.Println("Applying database migrations...")
 
	m, err := migrate.New(
		"file://"+migrationFolder,
		driver,
	)
	if err != nil {
		log.Fatalf("Failed to initialize migrations: %v", err)
	}
 
	if err := m.Up(); err != nil && err != migrate.ErrNoChange {
		log.Fatalf("Migration failed: %v", err)
	}
 
	log.Println("Database migrations applied successfully!")
}