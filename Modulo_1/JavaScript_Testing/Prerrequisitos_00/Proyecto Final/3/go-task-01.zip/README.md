# Welcome to Udemy Go Labs!

Go labs are based on Go ??? in the Ubuntu distribution. You can practice Go coding as you follow the lab tasks.

Following commands are also supported: 
* vim 
* wget 
* zsh
