import { Component } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent {

  comentarios: any [] = [{
    nombre: "Alfredo Leal", 
    alias: "@aleal",
    comentario: "Framework angular sigue evolucionando"
  },
  {
    nombre: "John Papa", 
    alias: "@jpapa",
    comentario: "Thank you for watching this tutotial"
  }]

  nombre: any;
  comentario: any;


  agregarComentario(){
    console.log(this.nombre);
    console.log(this.comentario);

    let comentarioAux = {
      nombre: this.nombre,
      alias: `@ ${this.nombre}`,
      comentario: this.comentario
    }

    this.comentarios.push(comentarioAux);
  }

  eliminar(indice: any){
    console.log("eliminar!!", indice)
    this.comentarios.splice(indice, 1);
  }

}
