DROP TABLE IF EXISTS client_apartments;
DROP TABLE IF EXISTS clients;