import java.util.InputMismatchException;
import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        int numero;

        try {
            System.out.println("Ingrese un valor entero");
            numero = teclado.nextInt();
            int dobleNum = dobleNumero(numero);
            System.out.println("El doble de número " + numero +" es: "+ dobleNum);

        } catch (InputMismatchException ex ){
            System.out.println(" Debe ingresar un número por teclado: ");
            ex.printStackTrace();
            ex.getMessage();
        } catch (ValorInvalido va) {
            System.out.println(" Debe ingresar un número positivo");
            va.printStackTrace();
            va.getCause();
        } finally {
            System.out.println(" Ejecutando bloque finally");
        }

    }

    public static int dobleNumero(int numero) throws InputMismatchException, ValorInvalido{
        if (!esNumerico(String.valueOf(numero)))
            throw new InputMismatchException();

        if (numero <= 0)
            throw new ValorInvalido("Debes ingresar un número positivo");

        return numero * 2;
    }

    public static boolean esNumerico(String valor){
        boolean resultado;

        try {
            Integer.parseInt(String.valueOf(valor));
            resultado = true;

        } catch (NumberFormatException nu){

            resultado = false;
        }

        return resultado;

    }
}